/**
 * concrete class for spirit
 */
public class Spirit extends Monster{

    public Spirit(String name, int level, int damage, int defenseStats, double dodgeChance) {
        super(name, level, damage, defenseStats, dodgeChance);
    }
}
