/**
 * concrete class for Exoskeleton
 */
public class Exoskeleton extends Monster {

    public Exoskeleton(String name, int level, int damage, int defenseStats, double dodgeChance) {
        super(name, level, damage, defenseStats, dodgeChance);
    }
}
