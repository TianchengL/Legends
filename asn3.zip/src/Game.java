/**
 * super class for all game program
 */
public abstract class Game
{
    public abstract void init();

    public abstract void playGame();
}