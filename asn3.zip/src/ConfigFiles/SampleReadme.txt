# CS611-Legends

Name
-------------------------------------------------------------------------------------------------
--Insert Name--
--BUID--


Files
-------------------------------------------------------------------------------------------------
<.java file> - <1 line comment about the file 




Notes:
-------------------------------------------------------------------------------------------------
1. Files to be parsed should be stored in ConfigFiles, for parser class to read class
2. Bonus Done
3. Things instructions to note


How to run:
-------------------------------------------------------------------------------------------------
1. Navigate to the directory after downloading the project
2. Run the following instructions on command line:
	javac *.java
	java Main.java
