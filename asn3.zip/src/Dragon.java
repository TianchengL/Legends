/**
 * concrete class for dragon extend monster class
 */
public class Dragon extends Monster{


    public Dragon(String name, int level, int damage, int defenseStats, double dodgeChance) {
        super(name, level, damage, defenseStats, dodgeChance);
    }
}
